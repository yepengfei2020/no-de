﻿// Type definitions for Angular File Upload 4.2.1
// Project: https://github.com/danialfarid/ng-file-upload
// Definitions by: John Reilly <https://github.com/johnnyreilly>
// Definitions: https://github.com/borisyankov/DefinitelyTyped

/// <reference path="../ng-file-upload/ng-file-upload.d.ts" />

// THIS FILE WILL REMOVE IF angular-file-upload.d.ts incoming.
