/// <reference path="./backbone.localstorage.d.ts" />

var store: Store = new Store('testStore');
store.findAll();

store.save();
