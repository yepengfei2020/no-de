/// <reference path="./absolute.d.ts" />

import absolute from 'absolute';

const x: boolean = absolute('/home/foo');
