/// <reference path="./abs.d.ts" />

import Abs from 'abs';

const x: string = Abs('/foo');
