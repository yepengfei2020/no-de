/// <reference path="bunyan-prettystream.d.ts" />

import PrettyStream = require("bunyan-prettystream");
var stream = new PrettyStream();
