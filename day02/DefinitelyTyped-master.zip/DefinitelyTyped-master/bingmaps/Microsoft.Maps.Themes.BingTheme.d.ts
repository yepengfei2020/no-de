﻿// Type definitions for Microsoft.Maps.Themes 7.0
// Project: http://msdn.microsoft.com/en-us/library/hh868061.aspx
// Definitions by: Eric Todd <https://github.com/ericrtodd>
// Definitions: https://github.com/borisyankov/DefinitelyTyped

declare module Microsoft.Maps.Themes {
    
    export class BingTheme {
        constructor();
    }

} 