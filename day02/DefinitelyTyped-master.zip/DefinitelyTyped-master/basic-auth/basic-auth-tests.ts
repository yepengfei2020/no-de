/// <reference path="basic-auth.d.ts" />

import auth = require('basic-auth');

auth(null);
