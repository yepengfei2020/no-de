/// <reference path="headroom.d.ts" />

new Headroom(document.getElementById('siteHead'));

new Headroom(document.getElementsByClassName('siteHead')[0]);

new Headroom(document.getElementsByClassName('siteHead')[0], {
	tolerance: 34
});

new Headroom(document.getElementsByClassName('siteHead')[0], {
	offset: 500
});
