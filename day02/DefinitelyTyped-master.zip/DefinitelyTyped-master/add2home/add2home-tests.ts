/// <reference path="add2home.d.ts" />

addToHome.show(false);
addToHome.close();
addToHome.reset();
