// Type definitions for chai-things
// Project: https://github.com/chaijs/chai-things
// Definitions by: David Broder-Rodgers <https://github.com/DavidBR-SW/>
// Definitions: https://github.com/DavidBR-SW/DefinitelyTyped

/// <reference path="../chai/chai.d.ts" />

declare module Chai {
    interface ArrayAssertion {
        include: ArrayInclude;
        contain: ArrayInclude;
        not: ArrayAssertion;
        all: Assertion;
    }

    interface ArrayInclude {
        (item: any): any;
        a: Item;
        an: Item;
        one: Something;
        some: Something;
        something: Something;
        any: Anything;
    }

    interface Anything extends Assertion {
        (): any;
        that: Assertion
        with: Assertion
    }

    interface Something extends Assertion {
        (): any;
        that: Assertion
        with: Assertion
    }

    interface Item {
        item: Something;
        thing: Something;
    }

    interface Deep {
        equals: Equal;
    }
}

interface Array<T> {
    should: Chai.ArrayAssertion;
}

declare module "chai-things" {
    function chaiThings(chai: any, utils: any): void;
    export = chaiThings;
}
